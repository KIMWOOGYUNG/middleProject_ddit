package yaksa.server.dao.pay;

import yaksa.server.vo.pay.PayVO;

public interface IPayDao {

	public int insertPay(PayVO payVO);
	

}
