package yaksa.chemist.controller.main;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MainController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private BorderPane outerBoarderPane;

    @FXML
    private ImageView logo;

    @FXML
    private Label labelMenu;

    @FXML
    private Button btnManagePres;

    @FXML
    private Button btnManagePharm;

    @FXML
    private Button btnManageInven;

    @FXML
    private Button btnStaitcs;

    @FXML
    private BorderPane innerBoardPane;

    @FXML
    private ImageView btnChatting;

    @FXML
    private Button btnMypage;

    @FXML
    private Button btnLogout;

    @FXML
    private Button btnClose;
  
    @FXML
    private Pane topPane;
    
    @FXML
    private Pane centerPane;
    
    @FXML
    private Label lblTime;

    @FXML
    void calendar(ActionEvent event) {

    }

    @FXML
    void chatting(MouseEvent event) {

    }

    @FXML
    void close(ActionEvent event) {
    	Stage stage = (Stage) btnClose.getScene().getWindow();
    	stage.close();
    }

    @FXML
    void famousSaying(ActionEvent event) {

    }

    @FXML
    void managePres(ActionEvent event) {
    	try {
			Parent childroot = FXMLLoader.load(getClass().getResource("../../fxml/prescription/PrescriptManage.fxml"));
    		outerBoarderPane.setCenter(childroot);
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	labelMenu.setText("처방 관리");
    }

    @FXML
    void gotoMain(MouseEvent event) {
    	try {
			Parent childroot = FXMLLoader.load(getClass().getResource("../../fxml/main/MainCenter.fxml"));
    		outerBoarderPane.setCenter(childroot);
		} catch (IOException e) {
			e.printStackTrace();
		}
    	labelMenu.setText("Main Page");
    }

    @FXML
    void logout(ActionEvent event) {

    }

    @FXML
    void map(ActionEvent event) {

    }

    @FXML
    void mypage(ActionEvent event) {

    }

    @FXML
    void schedule(ActionEvent event) {

    }

    @FXML
    void statics(ActionEvent event) {
//    	try {
//			Parent childroot = FXMLLoader.load(getClass().getResource("../../fxml/prescription/Prescription.fxml"));
//    		outerBoarderPane.setCenter(childroot);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//    	    	
    	
    	labelMenu.setText("통계");
    }

    @FXML
    void managePharm(ActionEvent event) {
//    	try {
//			Parent childroot = FXMLLoader.load(getClass().getResource("../../fxml/prescription/Prescription.fxml"));
//    		outerBoarderPane.setCenter(childroot);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//    	
    	labelMenu.setText("약국 관리");
    }

    @FXML
    void manageInven(ActionEvent event) {
    	try {
			Parent childroot = FXMLLoader.load(getClass().getResource("../../fxml/inventory/Inventory.fxml"));
    		outerBoarderPane.setCenter(childroot);
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	labelMenu.setText("재고 관리");
    }

    @FXML
    void initialize() {
    	try {
			Parent childroot = FXMLLoader.load(getClass().getResource("../../fxml/main/MainCenter.fxml"));
    		outerBoarderPane.setCenter(childroot);
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	Thread th = new Thread() {
    		@Override
    		public void run() {

    			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    			
    			while(true) {

    				String strTime = sdf.format(new Date());

    				Platform.runLater(() -> {	
    					lblTime.setText(strTime);
    				});			
    				
    				try {Thread.sleep(100);} catch (InterruptedException e) {}
    			}
    		}
    	};//쓰레드 끝...
    	th.setDaemon(true);
    	th.start();
    }
}
