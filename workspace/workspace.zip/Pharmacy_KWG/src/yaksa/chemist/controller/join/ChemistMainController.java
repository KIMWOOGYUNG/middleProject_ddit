package yaksa.chemist.controller.join;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import yaksa.chemist.vo.join.ChemistVO;

public class ChemistMainController {
	
	static ChemistVO cheVO;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private BorderPane outerBoarderPane;

    @FXML
    private BorderPane innerBoardPane;

    @FXML
    private Button logout;

    @FXML
    private Button close;

    @FXML
    private Label namelb;

    @FXML
    void exit(ActionEvent event) {
    	Stage stage = (Stage) close.getScene().getWindow();      
        stage.close();
    }

    @FXML
    void logoutBtn(ActionEvent event) {
    	Stage stage = (Stage) close.getScene().getWindow();      
        stage.close();
    }

    @FXML
    void initialize() {
    	if(ChemistMainController.cheVO!=null) {
    		namelb.setText(cheVO.getPharm_name());
    	}else {
    		namelb.setText("");
    	}
    }
}