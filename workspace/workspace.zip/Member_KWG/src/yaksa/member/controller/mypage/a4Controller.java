package yaksa.member.controller.mypage;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;

public class a4Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }

	public void setMainConterolloer(a1Controller a1Controller) {
		// TODO Auto-generated method stub
		
	}
}
