package yaksa.chemist.vo.inventory;

public class insertVO {

	private int insert_cnt;
	private String insert_inventory;
	private String inven_inprice;
	private String medi_name;
	private String insert_date;
	private String inven_code;
	
	
	


	public String getInven_code() {
		return inven_code;
	}


	public void setInven_code(String inven_code) {
		this.inven_code = inven_code;
	}


	public insertVO() {}
	
	
	public int getInsert_cnt() {
		return insert_cnt; 
	}

	public void setInsert_cnt(int insert_cnt) {
		this.insert_cnt = insert_cnt;
	}

	public String getInsert_inventory() {
		return insert_inventory;
	}

	public void setInsert_inventory(String insert_inventory) {
		this.insert_inventory = insert_inventory;
	}

	public String getInven_inprice() {
		return inven_inprice;
	}

	public void setInven_inprice(String inven_inprice) {
		this.inven_inprice = inven_inprice;
	}

	public String getMedi_name() {
		return medi_name;
	}

	public void setMedi_name(String medi_name) {
		this.medi_name = medi_name;
	}

	public String getInsert_date() {
		return insert_date;
	}

	public void setInsert_date(String insert_date) {
		this.insert_date = insert_date;
	}

	
	
	
	
}
