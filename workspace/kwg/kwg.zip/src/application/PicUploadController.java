package application;

import java.awt.Image;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

public class PicUploadController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btnUpload;

    @FXML
    private Button btnCancel;

    @FXML
    private Button btnOtherPic;

    @FXML
    private ImageView img;
    
    @FXML
    private Button btnOk;
    
    @FXML
    void ok(ActionEvent event) {
    	//������ �����Ŵ
    }

    @FXML
    void cancel(ActionEvent event) {
    	Stage stage = (Stage) btnCancel.getScene().getWindow();
    	stage.close();
    }

    @FXML
    void selectOtherPic(ActionEvent event) {
    	//�ٸ� ���� ����
    }
    
    
    @FXML
    void upload(ActionEvent event) {
    	//���� ����
    	FileChooser fileChooser = new FileChooser();
		fileChooser.getExtensionFilters().addAll(new ExtensionFilter("All Files", "*.*"), new ExtensionFilter("JPG ����(.jpg)", "*.jpg"), new ExtensionFilter("PNG ����(.png)", "*.png"));
		
		//������ ���� ����
		File showDir = new File("C:\\Users\\PC-18\\Desktop\\OpenDialog");
		fileChooser.setInitialDirectory(showDir);
		
		//����â ���� ������ ���� ���ϱ�
		
		Stage stage = (Stage)btnCancel.getScene().getWindow();
		File selectedFile = fileChooser.showOpenDialog(stage);
		System.out.println(selectedFile);
		
		if(selectedFile != null) {
			//txtArea.appendText(selectedFile.get);
			showDir = selectedFile.getParentFile();	//������ ������ ������ ������ ���� �� �� ��Ÿ������ ����
			
			//���� ������ �о�� TextArea�� ����ϱ�
			FileInputStream fis = null;
			BufferedInputStream bin = null;
			try {
				fis =  new FileInputStream(selectedFile);
				bin = new BufferedInputStream(fis);
				
				
				
				int singleCh = 0;
				while((singleCh=bin.read()) != -1){
					fis.write(singleCh);
				}
				
				img.setImage();
				fis.close();
				//primaryStage.setTitle(selectedFile.getName());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			
		}else {
			return;
		}
    }

    @FXML
    void initialize() {
        assert btnUpload != null : "fx:id=\"btnUpload\" was not injected: check your FXML file 'PicUpload.fxml'.";
        assert btnCancel != null : "fx:id=\"btnCancel\" was not injected: check your FXML file 'PicUpload.fxml'.";
        assert btnOtherPic != null : "fx:id=\"btnOtherPic\" was not injected: check your FXML file 'PicUpload.fxml'.";
        assert img != null : "fx:id=\"img\" was not injected: check your FXML file 'PicUpload.fxml'.";

    }
}
