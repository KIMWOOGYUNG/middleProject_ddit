package application;

public class PharmDetailController {

}
