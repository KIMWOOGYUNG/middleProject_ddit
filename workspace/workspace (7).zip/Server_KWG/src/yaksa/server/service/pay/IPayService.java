package yaksa.server.service.pay;

import yaksa.server.vo.pay.PayVO;

public interface IPayService {

	public int insertPay(PayVO payVO);
}
