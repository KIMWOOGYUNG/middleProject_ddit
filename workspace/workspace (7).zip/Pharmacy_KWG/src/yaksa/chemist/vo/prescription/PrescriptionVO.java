package yaksa.chemist.vo.prescription;

public class PrescriptionVO {
	private String phpres_code;
	private String phpres_date;
	private String phpres_validity;
	private String phpres_persue;
	private String pharm_id;
	private String mem_id;
	
	public PrescriptionVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public PrescriptionVO(String phpres_code, String phpres_date, String phpres_validity, String phpres_persue,
			String pharm_id, String mem_id) {
		super();
		this.phpres_code = phpres_code;
		this.phpres_date = phpres_date;
		this.phpres_validity = phpres_validity;
		this.phpres_persue = phpres_persue;
		this.pharm_id = pharm_id;
		this.mem_id = mem_id;
	}
	
	public String getPhpres_code() {
		return phpres_code;
	}
	public void setPhpres_code(String phpres_code) {
		this.phpres_code = phpres_code;
	}
	public String getPhpres_date() {
		return phpres_date;
	}
	public void setPhpres_date(String phpres_date) {
		this.phpres_date = phpres_date;
	}
	public String getPhpres_validity() {
		return phpres_validity;
	}
	public void setPhpres_validity(String phpres_validity) {
		this.phpres_validity = phpres_validity;
	}
	public String getPhpres_persue() {
		return phpres_persue;
	}
	public void setPhpres_persue(String phpres_persue) {
		this.phpres_persue = phpres_persue;
	}
	public String getPharm_id() {
		return pharm_id;
	}
	public void setPharm_id(String pharm_id) {
		this.pharm_id = pharm_id;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	
	
}
