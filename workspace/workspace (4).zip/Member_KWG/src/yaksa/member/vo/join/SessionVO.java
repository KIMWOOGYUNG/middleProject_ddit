package yaksa.member.vo.join;

public class SessionVO {
	// 세션 : 인터넷 브라우저가 열려있는 동안 유지되는 저장공간
	
	// 로그인 되어있는 유저의 정보를 저장
	public static MemberVO loginMember;
	

}
