package yaksa.chemist.vo.prescription;

public class SaleVO {
	private String sale_inventory;
	private int sale_sumprice;
	private String sale_salenum;
	private int sale_cnt;
	private String sale_saledate;
	
	
	
	public SaleVO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SaleVO(String sale_inventory, int sale_sumprice, String sale_salenum, int sale_cnt, String sale_saledate) {
		super();
		this.sale_inventory = sale_inventory;
		this.sale_sumprice = sale_sumprice;
		this.sale_salenum = sale_salenum;
		this.sale_cnt = sale_cnt;
		this.sale_saledate = sale_saledate;
	}
	
	public String getSale_inventory() {
		return sale_inventory;
	}
	public void setSale_inventory(String sale_inventory) {
		this.sale_inventory = sale_inventory;
	}
	public int getSale_sumprice() {
		return sale_sumprice;
	}
	public void setSale_sumprice(int sale_sumprice) {
		this.sale_sumprice = sale_sumprice;
	}
	public String getSale_salenum() {
		return sale_salenum;
	}
	public void setSale_salenum(String sale_salenum) {
		this.sale_salenum = sale_salenum;
	}
	public int getSale_cnt() {
		return sale_cnt;
	}
	public void setSale_cnt(int sale_cnt) {
		this.sale_cnt = sale_cnt;
	}
	public String getSale_saledate() {
		return sale_saledate;
	}
	public void setSale_saledate(String sale_saledate) {
		this.sale_saledate = sale_saledate;
	}
	
	
}
