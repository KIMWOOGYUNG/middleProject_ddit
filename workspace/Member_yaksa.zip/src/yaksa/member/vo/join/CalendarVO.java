package yaksa.member.vo.join;

public class CalendarVO {
	private String Cal_conn;
	private String Cal_edate;
	private String Cal_sdate;
	private String Cal_title;
	private String Emp_id;
	private int Cal_num;
	
	public CalendarVO() { }

	public CalendarVO(String cal_conn, String cal_edate, String cal_sdate, String cal_title, String emp_id,
			int cal_num) {
		super();
		Cal_conn = cal_conn;
		Cal_edate = cal_edate;
		Cal_sdate = cal_sdate;
		Cal_title = cal_title;
		Emp_id = emp_id;
		Cal_num = cal_num;
	}

	public String getCal_conn() {
		return Cal_conn;
	}

	public void setCal_conn(String cal_conn) {
		Cal_conn = cal_conn;
	}

	public String getCal_edate() {
		return Cal_edate;
	}

	public void setCal_edate(String cal_edate) {
		Cal_edate = cal_edate;
	}

	public String getCal_sdate() {
		return Cal_sdate;
	}

	public void setCal_sdate(String cal_sdate) {
		Cal_sdate = cal_sdate;
	}

	public String getCal_title() {
		return Cal_title;
	}

	public void setCal_title(String cal_title) {
		Cal_title = cal_title;
	}

	public String getEmp_id() {
		return Emp_id;
	}

	public void setEmp_id(String emp_id) {
		Emp_id = emp_id;
	}

	public int getCal_num() {
		return Cal_num;
	}

	public void setCal_num(int cal_num) {
		Cal_num = cal_num;
	}
	
	
	

}
