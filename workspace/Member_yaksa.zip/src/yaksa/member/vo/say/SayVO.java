package yaksa.member.vo.say;

public class SayVO {
	
	private int say_num;
	private  String say_famous;
	private  String say_man;
	
	
	public int getSay_num() {
		return say_num;
	}
	public void setSay_num(int say_num) {
		this.say_num = say_num;
	}
	public String getSay_famous() {
		return say_famous;
	}
	public void setSay_famous(String say_famous) {
		this.say_famous = say_famous;
	}
	public String getSay_man() {
		return say_man;
	}
	public void setSay_man(String say_man) {
		this.say_man = say_man;
	}
	
}
