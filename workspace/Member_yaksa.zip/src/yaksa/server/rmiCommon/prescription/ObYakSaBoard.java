package yaksa.server.rmiCommon.prescription;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ObYakSaBoard extends Remote {
	
	boolean Popup(String ClientName) throws RemoteException;; // 약보드에서 해당 알림창이 떠야함
// 약보드에서는 수락을 누르면 바로 chat에 접속하기에 따로 fx컨트롤할 필요가 없다.
	

}
