package yaksa.member.controller.main;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import yaksa.member.controller.join.MemMainController;
import yaksa.member.main.main.calendar.GNCalendarTile;
import yaksa.member.vo.join.MemberVO;

public class MainCenterController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Pane centerPane;

    @FXML
    private Button btnCalendar;
    
    @FXML
    private StackPane Calendar;

    @FXML
    private Button btnSchedule;

    @FXML
    private Button btnFamousSaying;

    @FXML
    private Button btnMap;
    
    static MemberVO memVO;

    @FXML
    void calendar(ActionEvent event) {
    	try {
    		Stage dialog = new Stage();
			Parent childRoot = FXMLLoader.load(MemMainController.class.getResource("../../fxml/join/calendar.fxml"));
			dialog.initStyle(StageStyle.TRANSPARENT); 
			Scene childScene = new Scene(childRoot);
			childScene.setFill(Color.TRANSPARENT);	
			
			dialog.setScene(childScene);
			dialog.setTitle("calendar");
			dialog.showAndWait();
    	} catch (Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void famousSaying(ActionEvent event) {

    }

    @FXML
    void map(ActionEvent event) {
//    	try {
//    		Stage dialog = new Stage();
//			Parent childRoot = FXMLLoader.load(MemMainController.class.getResource("../../fxml/map/YKSearch.fxml"));
//			dialog.initStyle(StageStyle.TRANSPARENT); 
//			Scene childScene = new Scene(childRoot);
//			childScene.setFill(Color.TRANSPARENT);	
//			
//			dialog.setScene(childScene);
//			dialog.setTitle("calendar");
//			dialog.showAndWait();
//    	} catch (Exception e) {
//			e.printStackTrace();
//		}

    }

    @FXML
    void schedule(ActionEvent event) {

    }

    @FXML
    void initialize() {
    	
    	GNCalendarTile btnCalendar = new GNCalendarTile();
    	
    	Calendar.getChildren().add(btnCalendar);

    }
}
