package yaksa.member.vo.join;

public class calDateVO {
	private String clickTitle;
	private String clickCont;
	private int cal_num;

	public calDateVO() { }
	
	public calDateVO(String clickTitle, String clickCont, int cal_num) {
		super();
		this.clickTitle = clickTitle;
		this.clickCont = clickCont;
		this.cal_num = cal_num;
	}

	public int getCal_num() {
		return cal_num;
	}

	public void setCal_num(int cal_num) {
		this.cal_num = cal_num;
	}

	public String getClickTitle() {
		return clickTitle;
	}

	public void setClickTitle(String clickTitle) {
		this.clickTitle = clickTitle;
	}

	public String getClickCont() {
		return clickCont;
	}

	public void setClickCont(String clickCont) {
		this.clickCont = clickCont;
	}
	
}

