package yaksa.member.controller.map;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import yaksa.member.service.map.SearchServiceImpl;
import yaksa.member.util.prescription.AlertUtil;
import yaksa.member.vo.map.PharmVO;

public class ContYKDetail {
	

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private Label LaPharmNM;

	@FXML
	private Label LaAdd1;

	@FXML
	private Label LaAdd2;

	@FXML
	private Label LaTel;

	@FXML
	private Label LaOPTime;

	@FXML
	private Label LaCLTime;

	@FXML
	private Label LaStar;

	@FXML
	private Button CloseBtn;

	@FXML
	private Button ChatBtn;

	@FXML
	private Button PcSendBtn;

	private SearchServiceImpl service;
	private PharmVO pvo;
	
	public static PharmVO pvo2;

	@FXML
	void PrecSend(ActionEvent event) {
		// 처방전 전송 버튼 눌렀을 때
		try {
			Stage dialog = new Stage();
			dialog.initModality(Modality.WINDOW_MODAL);
			Parent childRoot = FXMLLoader.load(getClass().getResource("../../fxml/prescription/PresUpload.fxml"));
			dialog.initStyle(StageStyle.TRANSPARENT);
			
			Scene childScene = new Scene(childRoot);
			childScene.setFill(Color.TRANSPARENT);
			dialog.setScene(childScene);
			dialog.setTitle("사진 업로드 완료");
			dialog.show();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@FXML
	void Chat(ActionEvent event) {
		// 채팅버튼 눌렀을 때
		AlertUtil.infoMsg("채팅창", "임시채팅창");
	}

	@FXML
	void Close(ActionEvent event) {
		Stage currentStage = (Stage) CloseBtn.getScene().getWindow();
		currentStage.close();
	}

	void showupdate(PharmVO pvo) {
		this.pvo = pvo;
		LaPharmNM.setText(pvo.getPharm_name());
		LaAdd1.setText(pvo.getPharm_add1());
		LaAdd2.setText(pvo.getPharm_add2());
		LaTel.setText(pvo.getPharm_tel());
		LaOPTime.setText(pvo.getPharm_opentime());
		LaCLTime.setText(pvo.getPharm_closetime());
		LaStar.setText(Integer.toString(pvo.getPharm_starrate()));
		
		pvo2 = pvo;
	}

	
	
	@FXML
	void initialize() {
		service = SearchServiceImpl.getInstance();
	}
}
