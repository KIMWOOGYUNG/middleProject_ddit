package yaksa.member.controller.map;


import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javax.swing.JFrame;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;
import yaksa.member.controller.join.MemMainController;

public class ContMaskSale {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Pane MaskMapView;

    @FXML
    private Button BackStageBtn;

    @FXML
    void BackStage(ActionEvent event) {
       //뒤로가기 버튼을 눌렀을 때 전화면으로 돌아간다. 

	   Stage stage = (Stage) BackStageBtn.getScene().getWindow();      
	   stage.close();
    }
    
 // webview를 불러오는 메소드
    private  void initFX() {
       JFrame frame = new JFrame("FX");

       frame.getContentPane().setLayout(null);

       final JFXPanel fxPanel = new JFXPanel();

       frame.add(fxPanel);
       frame.setVisible(true);

       fxPanel.setSize(new Dimension(750,400));
       fxPanel.setLocation(new Point(0, 27));

       frame.getContentPane().setPreferredSize(new Dimension(750,400));
       frame.pack();
       frame.setResizable(false);

       Platform.runLater(new Runnable() {
          public void run() {
             initAndLoadWebView(fxPanel);
          }
       });
    }

    private  void initAndLoadWebView(final JFXPanel fxPanel) {
       Group group = new Group();
       Scene scene = new Scene(group);
       fxPanel.setScene(scene);

       WebView webview = new WebView();
       group.getChildren().add(webview);
       webview.setMinSize(750,400);
       webview.setMaxSize(750,400);



       WebEngine webEngine = webview.getEngine();
       webEngine.load("http://localhost:8081/Map/PublicMaskSale.html");
    }

    @FXML
    void initialize() {
    	
    	System.out.println("여기");
       
       WebView webview = new WebView();
       webview.setMinSize(750,400);
       webview.setMaxSize(750,400);
      WebEngine webEngine = webview.getEngine();
      webEngine.load("http://localhost:8081/Map/PublicMaskSale.html");
      MaskMapView.getChildren().add(webview);
       
    }
}