package yaksa.member.service.say;

import java.util.List;

import yaksa.member.vo.say.SayVO;

public interface InterSayService {
	/**
	 * 명언의 모든 정보를 반환
	 * @return
	 */
	public List<SayVO> getAllSay();
	
	
}
