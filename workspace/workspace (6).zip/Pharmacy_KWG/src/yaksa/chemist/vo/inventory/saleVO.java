package yaksa.chemist.vo.inventory;

public class saleVO {

	private int sale_cnt;
	private String sale_inventory;
	private String inven_outprice;
	private String medi_name;
	private String sale_saledate;
	private String inven_code;
	
	
	public String getInven_code() {
		return inven_code;
	}



	public void setInven_code(String inven_code) {
		this.inven_code = inven_code;
	}



	public String getMedi_name() {
		return medi_name;
	}



	public void setMedi_name(String medi_name) {
		this.medi_name = medi_name;
	}



	public String getInven_outprice() {
		return inven_outprice;
	}



	public void setInven_outprice(String inven_outprice) {
		this.inven_outprice = inven_outprice;
	}



	public saleVO() {}
	
	
	
	public String getSale_inventory() {
		return sale_inventory;
	}
	public void setSale_inventory(String sale_inventory) {
		this.sale_inventory = sale_inventory;
	}
	
	
	public int getSale_cnt() {
		return sale_cnt;
	}
	public void setSale_cnt(int sale_cnt) {
		this.sale_cnt = sale_cnt;
	}
	public String getSale_saledate() {
		return sale_saledate;
	}
	public void setSale_saledate(String sale_saledate) {
		this.sale_saledate = sale_saledate;
	}
	
	
}
