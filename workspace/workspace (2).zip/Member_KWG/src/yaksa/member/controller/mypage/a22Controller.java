package yaksa.member.controller.mypage;

import java.net.URL;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class a22Controller {


    @FXML
    private URL location;

    @FXML
    private Button ok;

    @FXML
    void okbtn(ActionEvent event) {
    	Stage stage = (Stage) ok.getScene().getWindow();    
        stage.close();
    }

    @FXML
    void initialize() {
        assert ok != null : "fx:id=\"ok\" was not injected: check your FXML file 'a22_IdDelet.fxml'.";

    }

	public void setMainConterolloer(a2Controller a2Controller) {
		// TODO Auto-generated method stub
		
	}
}
